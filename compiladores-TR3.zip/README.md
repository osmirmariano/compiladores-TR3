# compiladores-TR3

Implementar computacionalmente, um programa que, a partir de expressões regulares na forma posfixa, oriundas do trabalho 1 ou fornecidas pelo usuário, construa um AFD (Autômato Finito Determinístico). A construção do AFD ser dará pelo Método da Construção de Subconjuntos a partir de um AFN-ɛ (Autômato Finito Não-determinístico com Movimento Vazio), que foi construído pelo algoritmo de Thompson a partir da expressão regular. Como saída, deve ser fornecido ao usuário o fecho-ɛ de cada um dos estados do AFN-ɛ e o AFD representado por meio de tabela de transições ou notação matemática.

