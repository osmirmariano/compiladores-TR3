#include <iostream>

using namespace std;

class Minimizacao{
	public:
		Minimizacao();
		~Minimizacao();
};